# Cave Escape — Class Reflection

A portfolio page reflecting on my work building **Cave Escape**, a 2D lava-cave platformer made in Unity.

## Publish on GitHub Pages
1. Create a new repository on GitHub (e.g. `cave-escape-reflection`, or `<your-username>.github.io` for your main site).
2. Upload everything in this folder (`index.html`, `style.css`, `assets/`, `.nojekyll`) to the repository root.
3. Go to **Settings → Pages**, set **Source** to *Deploy from a branch*, choose `main` and `/ (root)`, then Save.
4. After a minute your site will be live at `https://<your-username>.github.io/<repo-name>/`.

## Editing
- All text is in `index.html`; styles are in `style.css`.
- Images live in `assets/`. Click any image on the page to enlarge it.
